import React from "react";
import "./MonitoringService.css";

const services = [
  { id: "urban-heat", title: "Urban Heat", description: "Monitor urban heat islands and temperature variations.", image: "./urban-heat.jpg" },
  { id: "drought", title: "Drought", description: "Analyze drought patterns and water scarcity trends.", image: "./Drought.jpg" },
  { id: "water-quality", title: "Water Quality", description: "Assess water pollution levels using satellite data.", image: "./water-quality.jpg" },
  { id: "air-quality", title: "Air Quality", description: "Track air pollution and identify hazardous areas.", image: "./air-quality.jpg" }
];
const Services = ({ setPage }: { setPage: (page: string) => void }) => {
    const redirectToFlask = () => {
      window.location.href = "http://127.0.0.1:5000/"; // Redirect to Flask app
    };

  return (
    <div className="services-home-container">
      <div className="glow-circle circle1"></div>
      <div className="glow-circle circle2"></div>
      <div className="glow-circle circle3"></div>
      

      {/* Page Heading */}
      <div className="services-content">
        <h1>Our Services</h1>
        <p>We offer environmental monitoring on interactive maps, analycies, and AI-based recommendations for a greener Jeddah.</p>
      </div>

      {/* Services Grid */}
      <div className="services-grid">
        {services.map((service) => (
          <div 
            key={service.id} 
            className="service-card" 
            onClick={() => setPage(service.id)} // Use setPage instead of navigate
          >
            <img src={service.image} alt={service.title} className="service-icon" />
            <h3 className="service-title">{service.title}</h3>
            <p className="service-description">{service.description}</p>
            <button
              className="service-button"
              onClick={() => {
                if (service.id === "water-quality") {
                  redirectToFlask(); // go to Flask website
                } else {
                  setPage(service.id); // go to another page
                }
              }}
            >
              {`Check ${service.title}`}
            </button>

          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;

